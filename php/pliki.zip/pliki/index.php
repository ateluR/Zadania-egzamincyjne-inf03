<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styl.css">
    <title>Lista aktorów | KinoTEKA</title>
</head>
<body>
    <header id="nagłówek1">
        <h2>KinoTEKA</h2>
    </header>
    <header id="nagłówek2">
        <p><em>W naszej bazie znajdują się najlepsi aktorzy</em></p>
    </header>
    <main>
        <h1>Najlepsi aktorzy tylko w naszym kinie</h1>
<div id="wynik">
        <?php
            $baza = mysqli_connect("localhost", "root", "", "kino");
            $zapytanie=""
        ?>
        </div>
    </main>

    <footer>
        <p>Autor:0000000</p>
    </footer>
</body>
</html>